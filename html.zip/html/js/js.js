jQuery(function( $ ) {
	
    //alert("hi");
      
      


      jQuery('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
        fade: true,
        asNavFor: '.slider-nav',
        infinite: true
        
      });
      jQuery('.slider-nav').slick({
        slidesToShow: 8,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: false,
        arrows:false,
        centerMode: false,
        focusOnSelect: true,
        infinite: true
      });
      
      
     
      jQuery('.up-arrow').click(function(){
          $("html, body").animate({scrollTop : 0},700);
          return false;
      });
      
      
      jQuery( ".search" ).click(function() {
        jQuery(this).siblings(".search-box").toggleClass("active");
      });
      
      jQuery( ".menu-btn" ).click(function() {
        jQuery(".main-menu").addClass("active");
        jQuery("body").addClass("overflow");
      });
      
      jQuery( ".close" ).click(function() {
          jQuery(".main-menu").removeClass("active");
          jQuery("body").removeClass("overflow");
      });
      
      
  });
  